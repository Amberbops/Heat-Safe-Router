import { useEffect, useState, useCallback, useRef } from "react";

import {

  Shield,

  Activity,

  Info,

  CloudSun,

  Flame,

  CheckCircle2,

  RefreshCw,

  Sliders,

} from "lucide-react";

import { RouteMap } from "./components/Map";

import { RouteControls } from "./components/RouteControls";


import type { PresetLocation } from "./constants/presets";

import { RouteCard } from "./components/RouteCard";

import { RouteAnalytics } from "./components/RouteAnalytics";

import { WeatherWidget } from "./components/WeatherWidget";

import { SystemInfoModal } from "./components/SystemInfoModal";

import { checkHealth, fetchRoutePlan } from "./api/plannerApi";

import type { HealthResponse } from "./api/plannerApi";

import type { Coordinate, RoutePlanResponse, RouteItem } from "./types/route";

import { SUPPORTED_CITIES } from "./config/supportedCities";
import { validatePoint, distanceKm } from "./utils/locationValidation";

import "./App.css";



const INITIAL_CITY = SUPPORTED_CITIES[0];
const point = ([latitude, longitude]: [number, number]): Coordinate => ({ latitude, longitude });

export function App() {
  const [selectedCityId, setSelectedCityId] = useState<string>(INITIAL_CITY.id);
  const selectedCity = SUPPORTED_CITIES.find(city => city.id === selectedCityId) ?? INITIAL_CITY;
  const requestSequence = useRef(0);

  const clearResults = useCallback(() => {
    requestSequence.current += 1; // Ignore a previous request that completes late.
    setRoutePlan(null);
    setSelectedRouteId("");
    setError(null);
  }, []);


  const [origin, setOrigin] = useState<Coordinate>(() => point(INITIAL_CITY.defaultOrigin));

  const [destination, setDestination] = useState<Coordinate>(() => point(INITIAL_CITY.defaultDestination));

  const [routePlan, setRoutePlan] = useState<RoutePlanResponse | null>(null);

  const [selectedRouteId, setSelectedRouteId] = useState<string>("");

  const [isLoading, setIsLoading] = useState<boolean>(true);

  const [error, setError] = useState<string | null>(null);

  const [health, setHealth] = useState<HealthResponse | null>(null);

  const [healthError, setHealthError] = useState<string | null>(null);

  const [clickTargetMode, setClickTargetMode] = useState<"origin" | "destination" | "none">("none");

  const [showSystemModal, setShowSystemModal] = useState<boolean>(false);

  const [activeSidebarTab, setActiveSidebarTab] = useState<"routes" | "analytics">("routes");



  const planRouteWithCoords = useCallback(
    async (startCoord: Coordinate, endCoord: Coordinate, cityId: string) => {
      const requestId = ++requestSequence.current;
      setIsLoading(true);
      setError(null);
      setRoutePlan(null);
      setSelectedRouteId("");
      const city = SUPPORTED_CITIES.find(item => item.id === cityId);
      if (!city) {
        setError("This city is not yet supported.");
        setIsLoading(false);
        return;
      }
      const locationError = validatePoint(startCoord, city) || validatePoint(endCoord, city);
      if (locationError || distanceKm(startCoord, endCoord) < 0.01) {
        setError(locationError || "Choose two different points at least 10 metres apart.");
        setIsLoading(false);
        return;
      }
      try {
        const plan = await fetchRoutePlan(
          startCoord.latitude,
          startCoord.longitude,
          endCoord.latitude,
          endCoord.longitude,
          cityId
        );
        if (requestId !== requestSequence.current) return;
        setRoutePlan(plan);
        setSelectedRouteId(plan.recommendations["heat-safe"]?.route_id || plan.routes[0]?.route_id || "");
      } catch (err) {
        if (requestId !== requestSequence.current) return;
        setRoutePlan(null);
        setSelectedRouteId("");
        setError(err instanceof Error ? err.message : "Failed to compute routes");
      } finally {
        if (requestId === requestSequence.current) setIsLoading(false);
      }
    }, []
  );

  useEffect(() => {
    let active = true;
    checkHealth().then(res => {
      if (active) setHealth(res);
    }).catch(err => {
      if (active) setHealthError(err instanceof Error ? err.message : "AWS Backend unreachable");
    });
    return () => { active = false; };
  }, []);

  // Initial route check; in Strict Mode, the first request is invalidated on cleanup.
  useEffect(() => {
    void planRouteWithCoords(point(INITIAL_CITY.defaultOrigin), point(INITIAL_CITY.defaultDestination), INITIAL_CITY.id);
    return () => { requestSequence.current += 1; };
  }, [planRouteWithCoords]);

  const handleSelectCity = (id: string) => {
    const city = SUPPORTED_CITIES.find(item => item.id === id);
    if (!city) return;
    clearResults();
    setIsLoading(false);
    setClickTargetMode("none");
    setSelectedCityId(id);
    setOrigin(point(city.defaultOrigin));
    setDestination(point(city.defaultDestination));
  };

  const handleOriginChange = (coord: Coordinate) => {
    clearResults(); setIsLoading(false); setOrigin(coord);
  };
  const handleDestinationChange = (coord: Coordinate) => {
    clearResults(); setIsLoading(false); setDestination(coord);
  };

  // Existing presets are Indore-specific; do not apply them in other cities.
  const handleApplyPreset = (preset: PresetLocation) => {
    if (selectedCityId !== "indore") {
      setError("Choose Indore before using an Indore preset.");
      return;
    }
    handleOriginChange(preset.origin);
    handleDestinationChange(preset.dest);
    void planRouteWithCoords(preset.origin, preset.dest, selectedCityId);
  };

  const handleSwapCoordinates = () => {
    const nextOrigin = destination;
    const nextDest = origin;
    handleOriginChange(nextOrigin);
    handleDestinationChange(nextDest);
    void planRouteWithCoords(nextOrigin, nextDest, selectedCityId);
  };

  // Handle map click

  const handleMapClickLocation = (coord: Coordinate) => {

    if (clickTargetMode === "origin") {

      handleOriginChange(coord);

      setClickTargetMode("none");

    } else if (clickTargetMode === "destination") {

      handleDestinationChange(coord);

      setClickTargetMode("none");

    }

  };



  const selectedRoute: RouteItem | undefined = routePlan?.routes.find(

    (r) => r.route_id === selectedRouteId

  ) || routePlan?.routes[0];



  const fastestRoute: RouteItem | undefined = routePlan?.routes.find(

    (r) => r.route_id === routePlan.recommendations.fast?.route_id

  );



  return (

    <div className="app-container">

      {/* Top Header */}

      <header className="app-header">

        <div className="header-brand">

          <div className="brand-logo-wrap">

            <Shield className="brand-icon" size={24} />

            <Flame className="brand-flame" size={14} />

          </div>

          <div className="brand-text">

            <h1>Heat-Safe Router</h1>

            <span className="brand-tagline">{selectedCity.name} Heat-Aware Pedestrian Engine</span>

          </div>

        </div>



        <div className="header-actions">

          {/* AWS Live Status */}

          <div className="status-pill-wrap">

            {health ? (

              <span className="status-pill online" title={`Connected to ${health.service}`}>

                <span className="status-dot green" />

                AWS Active

              </span>

            ) : healthError ? (

              <span className="status-pill error" title={healthError}>

                <span className="status-dot red" />

                AWS Error

              </span>

            ) : (

              <span className="status-pill checking">

                <RefreshCw className="spin-icon" size={12} />

                Connecting...

              </span>

            )}

          </div>



          {/* Quick Weather Capsule in Header */}

          {routePlan?.weather && (

            <div className="weather-capsule">

              <CloudSun size={15} />

              <span>{routePlan.weather.temperature_c}°C</span>

              <span className="capsule-sub">{selectedCity.name}</span>

            </div>

          )}



          {/* Info Modal Trigger */}

          <button

            type="button"

            className="info-btn"

            onClick={() => setShowSystemModal(true)}

            title="View AWS System Architecture & Heat Weights"

          >

            <Info size={16} />

            <span>Architecture & Scoring</span>

          </button>

        </div>

      </header>



      {/* Main Layout Grid */}

      <main className="app-layout">

        {/* Left Sidebar: Controls, Cards, Analytics */}

        <aside className="app-sidebar">

          <div className="city-selector" style={{ padding: "14px 18px" }}>
            <label htmlFor="selected-city" style={{ display: "block", marginBottom: 8 }}>
              Select supported city
            </label>
            <select
              id="selected-city"
              value={selectedCityId}
              onChange={e => handleSelectCity(e.target.value)}
              style={{ width: "100%", padding: 10, borderRadius: 8 }}
            >
              {SUPPORTED_CITIES.map(city => (
                <option key={city.id} value={city.id}>{city.name}</option>
              ))}
            </select>
          </div>
          {/* Controls Card */}

          <RouteControls

            origin={origin}

            destination={destination}

            onChangeOrigin={handleOriginChange}

            onChangeDestination={handleDestinationChange}

            onSwapCoordinates={handleSwapCoordinates}

            onApplyPreset={handleApplyPreset}

            onSubmit={() => void planRouteWithCoords(origin, destination, selectedCityId)}

            isLoading={isLoading}

            clickTargetMode={clickTargetMode}

            setClickTargetMode={setClickTargetMode}

            errorMessage={error || undefined}

          />



          {/* Weather Widget */}

          {routePlan?.weather && (

            <WeatherWidget

              weather={routePlan.weather}

              heatCategory={selectedRoute?.heat.category}

            />

          )}



          {/* Navigation Tabs (Routes vs Deep Analytics) */}

          {routePlan && (

            <div className="sidebar-tabs">

              <button

                type="button"

                className={`tab-btn ${activeSidebarTab === "routes" ? "active" : ""}`}

                onClick={() => setActiveSidebarTab("routes")}

              >

                <Sliders size={15} />

                <span>Route Options ({routePlan.routes.length})</span>

              </button>

              <button

                type="button"

                className={`tab-btn ${activeSidebarTab === "analytics" ? "active" : ""}`}

                onClick={() => setActiveSidebarTab("analytics")}

              >

                <Activity size={15} />

                <span>Heat Analytics</span>

              </button>

            </div>

          )}



          {/* Tab Content: Routes List */}

          {activeSidebarTab === "routes" && routePlan && (

            <div className="routes-list-section">

              <div className="routes-list-header">

                <span className="routes-count">

                  {routePlan.routes.length} Alternatives Calculated

                </span>

                <span className="db-save-tag" title="Saved in AWS DynamoDB">

                  <CheckCircle2 size={12} /> DynamoDB: {routePlan.storage?.status ?? "unknown"}

                </span>

              </div>



              <div className="route-cards-stack">

                {/* Always prioritize the Heat-Safe route first */}

                {[...routePlan.routes]

                  .sort((a, b) => {

                    const aIsSafe = a.route_id === routePlan.recommendations["heat-safe"]?.route_id;

                    const bIsSafe = b.route_id === routePlan.recommendations["heat-safe"]?.route_id;

                    if (aIsSafe) return -1;

                    if (bIsSafe) return 1;

                    return a.heat.heat_score - b.heat.heat_score;

                  })

                  .map((route) => (

                    <RouteCard

                      key={route.route_id}

                      route={route}

                      isSelected={route.route_id === selectedRouteId}

                      recommendations={routePlan.recommendations}

                      fastestRoute={fastestRoute}

                      onSelect={(id) => setSelectedRouteId(id)}

                    />

                  ))}

              </div>

            </div>

          )}



          {/* Tab Content: Deep Analytics */}

          {activeSidebarTab === "analytics" && selectedRoute && (

            <RouteAnalytics route={selectedRoute} />

          )}

        </aside>



        {/* Right Pane: Interactive Map */}

        <section className="app-map-section">

          {clickTargetMode !== "none" && (

            <div className="map-instruction-overlay">

              <span>

                Click anywhere on the map to set <strong>{clickTargetMode.toUpperCase()}</strong>

              </span>

              <button

                type="button"

                className="cancel-pick-btn"

                onClick={() => setClickTargetMode("none")}

              >

                Cancel

              </button>

            </div>

          )}



          <RouteMap

            origin={origin}

            destination={destination}

            routes={routePlan?.routes || []}

            selectedRouteId={selectedRouteId}

            recommendedRouteId={routePlan?.recommendations["heat-safe"]?.route_id}

            onSelectRoute={(id) => setSelectedRouteId(id)}

            onMapClickLocation={handleMapClickLocation}

            clickTargetMode={clickTargetMode}

          />

        </section>

      </main>



      {/* System & Architecture Modal */}

      <SystemInfoModal

        isOpen={showSystemModal}

        onClose={() => setShowSystemModal(false)}

        model={routePlan?.model}

        requestId={routePlan?.request_id}

        storageStatus={routePlan?.storage?.status}

        tableName={routePlan?.storage?.table}

      />

    </div>

  );

}



export default App;