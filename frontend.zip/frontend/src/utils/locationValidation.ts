import type { Coordinate } from "../types/route";
import type { SupportedCity } from "../config/supportedCities";

export function distanceKm(a: Coordinate, b: Coordinate): number {
  const rad = (degrees: number) => (degrees * Math.PI) / 180;
  const dLat = rad(b.latitude - a.latitude);
  const dLon = rad(b.longitude - a.longitude);
  const h = Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.latitude)) * Math.cos(rad(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.min(1, Math.sqrt(h)));
}

export function validatePoint(point: Coordinate, city: SupportedCity): string | null {
  if (!Number.isFinite(point.latitude) || !Number.isFinite(point.longitude) ||
      Math.abs(point.latitude) > 90 || Math.abs(point.longitude) > 180) {
    return "Enter valid latitude and longitude coordinates.";
  }
  const center: Coordinate = { latitude: city.center[0], longitude: city.center[1] };
  return distanceKm(point, center) <= city.radiusKm
    ? null
    : `Location is outside the supported ${city.name} area.`;
}
