export type SupportedCity = {
  id: string;
  name: string;
  center: [number, number];
  radiusKm: number;
  defaultOrigin: [number, number];
  defaultDestination: [number, number];
};

export const SUPPORTED_CITIES: SupportedCity[] = [
  {
    id: "indore",
    name: "Indore",
    center: [22.7196, 75.8577],
    radiusKm: 12,
    defaultOrigin: [22.7196, 75.8577],
    defaultDestination: [22.7256, 75.8656],
  },
];