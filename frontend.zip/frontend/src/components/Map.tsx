import React, { useEffect, useMemo } from "react";
import {
  MapContainer,
  TileLayer,
  Polyline,
  Marker,
  Popup,
  useMap,
  useMapEvents,
} from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { RouteItem, Coordinate } from "../types/route";

// Fix standard Leaflet marker icons in bundlers.
delete (L.Icon.Default.prototype as unknown as { _getIconUrl?: unknown })._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const createOriginIcon = () =>
  L.divIcon({
    className: "custom-map-marker marker-origin",
    html: `<div class="marker-pin origin-pin"><span class="marker-dot"></span><span class="marker-label">A</span></div>`,
    iconSize: [34, 34],
    iconAnchor: [17, 34],
    popupAnchor: [0, -32],
  });

const createDestIcon = () =>
  L.divIcon({
    className: "custom-map-marker marker-dest",
    html: `<div class="marker-pin dest-pin"><span class="marker-dot"></span><span class="marker-label">B</span></div>`,
    iconSize: [34, 34],
    iconAnchor: [17, 34],
    popupAnchor: [0, -32],
  });

interface MapProps {
  origin: Coordinate;
  destination: Coordinate;
  routes: RouteItem[];
  selectedRouteId: string;
  recommendedRouteId?: string;
  onSelectRoute: (routeId: string) => void;
  onMapClickLocation?: (coord: Coordinate) => void;
  clickTargetMode: "origin" | "destination" | "none";
}

function MapBoundsUpdater({
  origin,
  destination,
  routes,
  selectedRoute,
}: {
  origin: Coordinate;
  destination: Coordinate;
  routes: RouteItem[];
  selectedRoute?: RouteItem;
}) {
  const map = useMap();

  useEffect(() => {
    const points: L.LatLngTuple[] = [];
    const routeSet = selectedRoute ? [selectedRoute] : routes;

    for (const route of routeSet) {
      for (const [lon, lat] of route.geometry?.coordinates ?? []) {
        if (Number.isFinite(lat) && Number.isFinite(lon)) {
          points.push([lat, lon]);
        }
      }
    }

    if (!points.length) {
      if (Number.isFinite(origin.latitude) && Number.isFinite(origin.longitude)) {
        points.push([origin.latitude, origin.longitude]);
      }
      if (Number.isFinite(destination.latitude) && Number.isFinite(destination.longitude)) {
        points.push([destination.latitude, destination.longitude]);
      }
    }

    if (points.length === 1) {
      map.setView(points[0], 14);
    } else if (points.length > 1) {
      map.fitBounds(L.latLngBounds(points), {
        padding: [50, 50],
        maxZoom: 16,
        animate: true,
      });
    }
  }, [
    map,
    origin.latitude,
    origin.longitude,
    destination.latitude,
    destination.longitude,
    routes,
    selectedRoute,
  ]);

  return null;
}

function MapClickHandler({
  onMapClickLocation,
  clickTargetMode,
}: {
  onMapClickLocation?: (coord: Coordinate) => void;
  clickTargetMode: "origin" | "destination" | "none";
}) {
  useMapEvents({
    click(e: L.LeafletMouseEvent) {
      if (clickTargetMode !== "none" && onMapClickLocation) {
        onMapClickLocation({
          latitude: Number(e.latlng.lat.toFixed(5)),
          longitude: Number(e.latlng.lng.toFixed(5)),
        });
      }
    },
  });
  return null;
}

export const RouteMap: React.FC<MapProps> = ({
  origin,
  destination,
  routes,
  selectedRouteId,
  recommendedRouteId,
  onSelectRoute,
  onMapClickLocation,
  clickTargetMode,
}) => {
  const selectedRoute = routes.find((r) => r.route_id === selectedRouteId);
  const originIcon = useMemo(createOriginIcon, []);
  const destIcon = useMemo(createDestIcon, []);

  const getRouteColor = (route: RouteItem, isSelected: boolean) => {
    const isRecommended = route.route_id === recommendedRouteId;
    if (isSelected) {
      if (isRecommended) return "#10b981";
      if (route.mode_scores?.fast !== undefined) return "#f59e0b";
      return "#0284c7";
    }
    return "#94a3b8";
  };

  return (
    <div className="map-wrapper">
      <MapContainer
        center={[origin.latitude, origin.longitude]}
        zoom={14}
        scrollWheelZoom={true}
        className="map-container"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <MapBoundsUpdater
          origin={origin}
          destination={destination}
          routes={routes}
          selectedRoute={selectedRoute}
        />
        <MapClickHandler
          onMapClickLocation={onMapClickLocation}
          clickTargetMode={clickTargetMode}
        />

        <Marker position={[origin.latitude, origin.longitude]} icon={originIcon}>
          <Popup>
            <div className="marker-popup-content">
              <strong>Origin (Start)</strong>
              <div>Lat: {origin.latitude}, Lon: {origin.longitude}</div>
            </div>
          </Popup>
        </Marker>

        <Marker position={[destination.latitude, destination.longitude]} icon={destIcon}>
          <Popup>
            <div className="marker-popup-content">
              <strong>Destination (End)</strong>
              <div>Lat: {destination.latitude}, Lon: {destination.longitude}</div>
            </div>
          </Popup>
        </Marker>

        {routes
          .filter((r) => r.route_id !== selectedRouteId)
          .map((route) => {
            const coords = (route.geometry?.coordinates || []).map(
              ([lon, lat]) => [lat, lon] as [number, number]
            );

            return (
              <Polyline
                key={route.route_id}
                positions={coords}
                pathOptions={{
                  color: getRouteColor(route, false),
                  weight: 4,
                  opacity: 0.5,
                  dashArray: "6, 6",
                }}
                eventHandlers={{
                  click: () => onSelectRoute(route.route_id),
                }}
              >
                <Popup>
                  <div className="route-popup">
                    <h4>{route.route_id.toUpperCase()}</h4>
                    <p>Heat Score: {route.heat.heat_score}/100</p>
                    <p>Duration: {route.duration_min} min</p>
                    <p>Distance: {route.distance_km} km</p>
                    <button
                      className="popup-btn"
                      onClick={() => onSelectRoute(route.route_id)}
                    >
                      Select Route
                    </button>
                  </div>
                </Popup>
              </Polyline>
            );
          })}

        {selectedRoute && (
          <Polyline
            key={`selected-${selectedRoute.route_id}`}
            positions={(selectedRoute.geometry?.coordinates || []).map(
              ([lon, lat]) => [lat, lon] as [number, number]
            )}
            pathOptions={{
              color: getRouteColor(selectedRoute, true),
              weight: 6,
              opacity: 0.95,
            }}
          >
            <Popup>
              <div className="route-popup">
                <h4>
                  {selectedRoute.route_id.toUpperCase()}{" "}
                  {selectedRoute.route_id === recommendedRouteId ? "★ Recommended" : ""}
                </h4>
                <p>
                  <strong>Heat Score:</strong> {selectedRoute.heat.heat_score}/100 (
                  {selectedRoute.heat.category})
                </p>
                <p><strong>Duration:</strong> {selectedRoute.duration_min} min</p>
                <p><strong>Distance:</strong> {selectedRoute.distance_km} km</p>
              </div>
            </Popup>
          </Polyline>
        )}
      </MapContainer>
    </div>
  );
};
